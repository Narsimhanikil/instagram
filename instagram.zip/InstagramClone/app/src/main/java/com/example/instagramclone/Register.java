package com.example.instagramclone;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Register extends AppCompatActivity {
    private EditText username,name,email,password;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mrootRef;
    private Button register;
    private TextView loginuser;
    ProgressDialog progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        username=findViewById(R.id.username);
        name=findViewById(R.id.fullname);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        loginuser=findViewById(R.id.loginuser);
        register=findViewById(R.id.reg);
        mrootRef= FirebaseDatabase.getInstance().getReference();
        firebaseAuth=FirebaseAuth.getInstance();
        progress=new ProgressDialog(this);
        loginuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Register.this,Login.class));
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textusername=username.getText().toString();
                String textname=name.getText().toString();
                String textemail=email.getText().toString();
                String textpassword=password.getText().toString();
                if(TextUtils.isEmpty(textusername)|| TextUtils.isEmpty(textname)||TextUtils.isEmpty(textemail)||TextUtils.isEmpty(textpassword)){
                    Toast.makeText(Register.this, "Empty Credentials", Toast.LENGTH_SHORT).show();
                }else if(textpassword.length()<6){
                    Toast.makeText(Register.this, "Password to strength", Toast.LENGTH_SHORT).show();
                }else{
                    registeruser(textusername,textname,textemail,textpassword);


                }
            }
        });
    }

    private void registeruser(final String username, final String name, final String email, String password) {
        progress.setMessage("PLEASE WAIT");
        progress.show();
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                HashMap<String,Object> map=new HashMap<>();
                map.put("name",name);
                map.put("email",email);
                map.put("username",username);
                map.put("id",firebaseAuth.getUid());
                map.put("bio","");
                map.put("imageurl","default");
                mrootRef.child("users").child(firebaseAuth.getCurrentUser().getUid()).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                           progress.dismiss();
                            Toast.makeText(Register.this, "update the profile for better experience", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(Register.this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP));
                            finish();
                        }
                    }
                });
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                progress.dismiss();
                Toast.makeText(Register.this,e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}